@extends('layout.head')

@section('container')
    <body>
        
@endsection