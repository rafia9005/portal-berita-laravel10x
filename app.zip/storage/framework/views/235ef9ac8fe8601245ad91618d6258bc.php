

<?php $__env->startSection('container'); ?>
    <?php $__currentLoopData = $dataKeluhanUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keluhan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Nama: <?php echo e($keluhan->nama); ?></p>
        <p>Email: <?php echo e($keluhan->email); ?></p>
        <p>Keluhan: <?php echo e($keluhan->keluhan); ?></p>
        <p>Action: <?php echo e($keluhan->action); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BEST PROJECT LARAVEL\peneldev\resources\views/user/user-data-keluhan.blade.php ENDPATH**/ ?>