<?php if(session('message')): ?>
    <p><?php echo e(session('message')); ?></p>
<?php endif; ?>

<form method="POST" action="/mail/send">
    <?php echo csrf_field(); ?>
    <label for="email">Alamat Email Penerima:</label>
    <input type="email" name="email" required><br><br>
    <label for="subject">Subjek Email:</label>
    <input type="text" name="subject" required><br><br>
    <label for="message">Isi Pesan:</label><br>
    <textarea name="message" rows="4" cols="50" required></textarea><br><br>
    <button type="submit">Kirim Email</button>
</form>
<?php /**PATH F:\BEST PROJECT LARAVEL\peneldev\resources\views/email/send.blade.php ENDPATH**/ ?>