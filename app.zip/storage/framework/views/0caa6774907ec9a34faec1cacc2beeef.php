

<?php $__env->startSection('container'); ?>
    <body>
        <div id="app">
            <input type="text" v-model="message" @keyup.enter="sendMessage">
            <ul>
                <li v-for="msg in messages">{{ msg }}</li>
            </ul>
        </div>
    
        <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
        <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
        <script>
            new Vue({
                el: '#app',
                data: {
                    message: '',
                    messages: []
                },
                methods: {
                    sendMessage() {
                        // Kirim pesan ke server
                        axios.post('/send-message', { message: this.message })
                            .then(response => {
                                console.log(response.data.message);
                                this.message = '';
                            })
                            .catch(error => {
                                console.error(error);
                            });
                    }
                },
                mounted() {
                    const pusher = new Pusher('your-app-key', {
                        cluster: 'mt1',
                        encrypted: true
                    });
    
                    const channel = pusher.subscribe('chat');
                    channel.bind('App\\Events\\NewMessageEvent', data => {
                        this.messages.push(data.message);
                    });
                }
            });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BEST PROJECT LARAVEL\peneldev\resources\views/feature/chat.blade.php ENDPATH**/ ?>