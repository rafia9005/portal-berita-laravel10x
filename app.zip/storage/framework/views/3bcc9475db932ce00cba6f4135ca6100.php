<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h2><?php echo e($berita->judul); ?></h2>
    <p><?php echo e($berita->deskripsi); ?></p>
    <?php if($berita->thumbnail): ?>
        <img src="<?php echo e(asset('storage/' . $berita->thumbnail)); ?>" alt="Thumbnail">
    <?php endif; ?>
    <div><?php echo $berita->konten; ?></div>

</body>

</html>
<?php /**PATH F:\BEST PROJECT LARAVEL\peneldev\resources\views/feature/berita-view.blade.php ENDPATH**/ ?>