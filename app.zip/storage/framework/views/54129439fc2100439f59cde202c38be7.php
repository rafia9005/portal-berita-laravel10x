<form action="/send-message" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="phone_number" placeholder="Nomor Tujuan">
    <textarea name="message" placeholder="Pesan"></textarea>
    <button type="submit">Kirim Pesan</button>
</form>
<?php /**PATH F:\BEST PROJECT LARAVEL\peneldev\resources\views/sms/send.blade.php ENDPATH**/ ?>