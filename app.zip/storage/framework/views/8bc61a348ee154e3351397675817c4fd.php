

<?php $__env->startSection('container'); ?>
    <form action="<?php echo e(route('kirim.keluhan')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="nama">Nama:</label><br>
        <input type="text" id="nama" name="nama" required><br><br>

        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="keluhan">Keluhan:</label><br>
        <textarea id="keluhan" name="keluhan" rows="4" required></textarea><br><br>

        <button type="submit">Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BEST PROJECT LARAVEL\peneldev\resources\views/feature/keluhan-masyarakat.blade.php ENDPATH**/ ?>